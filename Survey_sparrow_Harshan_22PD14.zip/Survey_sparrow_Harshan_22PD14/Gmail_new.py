import os
import pickle
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import base64
import email
from email.mime.text import MIMEText
import re
import streamlit as st
from transformers import pipeline, AutoModelForCausalLM, AutoTokenizer
import torch
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
import numpy as np

SCOPES = ['https://www.googleapis.com/auth/gmail.send', 'https://www.googleapis.com/auth/gmail.modify']


def authenticate_gmail():
    creds = None
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except Exception as e:
                st.error(f"Error refreshing credentials: {e}")
                os.remove('token.pickle')
                return authenticate_gmail()
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return creds

def get_gmail_service():
    """Builds the Gmail API service."""
    creds = authenticate_gmail()
    service = build('gmail', 'v1', credentials=creds)
    return service

def train_email_classifier(training_data):
    # Extract features and labels
    texts = [item[0] for item in training_data]
    labels = [item[1] for item in training_data]
    
    # Create and train the classifier
    classifier = Pipeline([
        ('vectorizer', CountVectorizer(stop_words='english', 
                                      min_df=1, 
                                      ngram_range=(1, 2))),
        ('classifier', MultinomialNB(alpha=1.0))
    ])
    
    classifier.fit(texts, labels)
    
    # Save the model
    with open('email_classifier.pkl', 'wb') as f:
        pickle.dump(classifier, f)
    
    return classifier

def collect_training_data(email_data, category):
    # Combine features for classification
    subject = email_data.get('subject', '')
    sender = email_data.get('from', '')
    body = email_data.get('body', '')
    email_text = f"Subject: {subject}\nFrom: {sender}\n\n{body}"
    
    # Load existing training data
    training_data = []
    if os.path.exists('training_data.pkl'):
        try:
            with open('training_data.pkl', 'rb') as f:
                training_data = pickle.load(f)
        except:
            training_data = []
    
    # Add new training example
    training_data.append((email_text, category))
    
    # Save updated training data
    with open('training_data.pkl', 'wb') as f:
        pickle.dump(training_data, f)
    
    # Retrain model if we have enough data
    if len(training_data) >= 10:
        train_email_classifier(training_data)
        return True
    
    return False

def rule_based_categorization(email_data):
    """Simple rule-based categorization as fallback."""
    subject = email_data.get('subject', '').lower()
    sender = email_data.get('from', '').lower()

    if "urgent" in subject or "immediate action" in subject:
        return "🔴 Urgent"
    elif "follow up" in subject or "reminder" in subject:
        return "🟡 Follow-up"
    else:
        return "🟢 Low Priority"

def categorize_email(email_data):
    """Categorize email using Naive Bayes classification."""
    subject = email_data.get('subject', '')
    sender = email_data.get('from', '')
    body = email_data.get('body', '')
    
    # Combine features for classification
    email_text = f"Subject: {subject}\nFrom: {sender}\n\n{body}"
    
    # Check if we have a trained model
    model_path = 'email_classifier.pkl'
    if os.path.exists(model_path):
        # Load existing model
        try:
            with open(model_path, 'rb') as f:
                classifier = pickle.load(f)
            
            # Predict category
            prediction = classifier.predict([email_text])[0]
            return prediction
        except Exception as e:
            st.warning(f"Error loading classifier: {e}. Using fallback classification.")
    
    # Fallback to rule-based classification if no model exists
    return rule_based_categorization(email_data)

def summarize_email_thread(service, thread_id):
    try:
        with st.spinner('Generating summary...'):
            thread = service.users().threads().get(userId='me', id=thread_id).execute()
            messages = thread['messages']

            all_text = ""
            for msg in messages:
                msg_data = get_message_data(service, msg['id'])
                all_text += msg_data.get('body', '') + "\n"

            sentences = re.split(r'[.!?]+', all_text)
            summary = ". ".join(sentences[:min(3, len(sentences))])

            if summary:
                st.markdown("### 📝 Summary")
                st.markdown(f"""
                    <div style='background-color: #f0f2f6; 
                              padding: 15px; 
                              border-radius: 5px; 
                              border-left: 5px solid #ff4b4b;'>
                    {summary.strip()}
                    </div>
                """, unsafe_allow_html=True)
                return summary.strip()
            else:
                return "No summary available."

    except Exception as e:
        st.error(f"Error summarizing thread: {e}")
        return "Error generating summary."


def get_message_data(service, msg_id):
    """Retrieves and decodes email content."""
    try:
        message = service.users().messages().get(userId='me', id=msg_id, format='raw').execute()
        msg_str = base64.urlsafe_b64decode(message['raw'].encode('ASCII'))
        mime_msg = email.message_from_bytes(msg_str)

        email_data = {
            'subject': mime_msg['subject'],
            'from': mime_msg['from'],
            'to': mime_msg['to'],
            'date': mime_msg['date']
        }

        body = ""
        if mime_msg.is_multipart():
            for part in mime_msg.walk():
                ctype = part.get_content_type()
                cdispo = str(part.get('Content-Disposition'))

                if ctype == 'text/plain' and 'attachment' not in cdispo:
                    body = part.get_payload(decode=True).decode()
        else:
            body = mime_msg.get_payload(decode=True).decode()

        email_data['body'] = body
        return email_data

    except Exception as e:
        st.error(f"Error getting message data: {e}")
        return {}

from transformers import AutoTokenizer, AutoModelForCausalLM
import torch

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import torch

def suggest_quick_replies(email_data):
    """Generate contextual quick replies using FLAN-T5."""
    try:
        if 'model' not in st.session_state:
            with st.spinner('Loading language model...'):
                model_name = "google/flan-t5-base"  # Smaller, freely accessible model
                st.session_state.tokenizer = AutoTokenizer.from_pretrained(model_name)
                st.session_state.model = AutoModelForSeq2SeqLM.from_pretrained(
                    model_name,
                    device_map="auto"
                )

        subject = email_data.get('subject', '')
        body = email_data.get('body', '')
        sender = email_data.get('from', '')

        # Create prompt
        prompt = f"""
        Email from: {sender}
        Subject: {subject}
        Content: {body}

        Generate three professional email replies. Be concise and appropriate.
        """

        # Generate responses
        device = st.session_state.model.device
        inputs = st.session_state.tokenizer(prompt, return_tensors="pt", max_length=512, truncation=True).to(device)

        
        # inputs = st.session_state.tokenizer(prompt, return_tensors="pt", max_length=512, truncation=True)
        
        responses = []
        for _ in range(3):  # Generate 3 different responses
            outputs = st.session_state.model.generate(
                inputs.input_ids,
                max_length=150,
                temperature=0.7,
                num_return_sequences=3,
                do_sample=True
            )
            
            decoded = st.session_state.tokenizer.decode(outputs[0], skip_special_tokens=True)
            responses.append(decoded.strip())

        # Format responses
        formatted_responses = []
        for response in responses:
            # Add greeting if not present
            if not response.lower().startswith(('hi', 'hello', 'dear')):
                response = f"Hello,\n\n{response}"
            
            # Add signature if not present
            if not response.lower().endswith(('regards', 'best', 'sincerely')):
                response = f"{response}\n\nBest regards"
            
            formatted_responses.append(response)

        return formatted_responses

    except Exception as e:
        st.error(f"Error generating replies: {e}")
        # Fallback responses
        return [
            "Thank you for your email. I'll get back to you soon.",
            "I've received your message and will respond shortly.",
            "Thanks for reaching out. I'll review and respond soon."
        ]


def add_label(service, msg_id, label_id):
    """Adds a label to a Gmail message."""
    try:
        service.users().messages().modify(userId='me', id=msg_id, body={'addLabelIds': [label_id]}).execute()
        return True
    except Exception as e:
        st.error(f"Error adding label: {e}")
        return False

def get_or_create_label(service, label_name):
    """Gets a label ID by name, or creates it if it doesn't exist."""
    try:
        labels = service.users().labels().list(userId='me').execute().get('labels', [])
        for label in labels:
            if label['name'] == label_name:
                return label['id']

        label = {'name': label_name,
                'labelListVisibility': 'labelShow',
                'messageListVisibility': 'show'}
        created_label = service.users().labels().create(userId='me', body=label).execute()
        return created_label['id']

    except Exception as e:
        st.error(f"Error with label: {e}")
        return None

import base64
import ssl
from email.mime.text import MIMEText
import streamlit as st

def send_reply(service, to, subject, message_text):
    """Sends an email reply with proper encoding and error handling."""
   
    try:
        # Create the email message
        message = MIMEText(message_text)
        message['to'] = to
        message['subject'] = f"Re: {subject}"
        message['from'] = "harshanmhs1711@gmail.com"  # You might want to get this from credentials

        # Properly encode message
        raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()

        # Send email via Gmail API
        sent_message = service.users().messages().send(
            userId='me', 
            body={'raw': raw_message}
        ).execute()
        
        st.success("Email sent successfully!")
        return True

    except Exception as e:
        # Print detailed error information
        import traceback
        error_details = traceback.format_exc()
        st.error(f"Error sending email: {str(e)}")
        st.error(f"Error details: {error_details}")
        return False

def clear_model_data():
        # Clear Streamlit session state
        if 'model' in st.session_state:
            del st.session_state['model']
        if 'tokenizer' in st.session_state:
            del st.session_state['tokenizer']
        if 'llama_model' in st.session_state:
            del st.session_state['llama_model']
        if 'llama_tokenizer' in st.session_state:
            del st.session_state['llama_tokenizer']

        # Use D drive for cache
        cache_dir = "D:/.cache/huggingface"
        if os.path.exists(cache_dir):
            try:
                import shutil
                shutil.rmtree(cache_dir)
                st.success("Successfully cleared model cache from D drive!")
            except Exception as e:
                st.error(f"Error clearing cache: {e}")

     # Set environment variable to use D drive for new downloads
        os.environ['TRANSFORMERS_CACHE'] = "D:/.cache/huggingface"
        os.environ['HF_HOME'] = "D:/.cache/huggingface"


def initialize_classifier():
    """Initialize the classifier with some example data if it doesn't exist."""
    if not os.path.exists('email_classifier.pkl'):
        # Example training data
        training_data = [
            ("Subject: Urgent: Action required\nFrom: boss@example.com\n\nPlease complete this task immediately.", "🔴 Urgent"),
            ("Subject: URGENT: Server down\nFrom: admin@example.com\n\nThe server is down, please check.", "🔴 Urgent"),
            ("Subject: Follow up on meeting\nFrom: colleague@example.com\n\nJust following up on our discussion.", "🟡 Follow-up"),
            ("Subject: Reminder: Submit report\nFrom: manager@example.com\n\nDon't forget to submit your report.", "🟡 Follow-up"),
            ("Subject: Newsletter\nFrom: news@example.com\n\nHere's your weekly newsletter.", "🟢 Low Priority"),
            ("Subject: Discount offer\nFrom: marketing@example.com\n\nSpecial discount just for you!", "🟢 Low Priority"),
        ]
        
        # Train the classifier
        train_email_classifier(training_data)
        st.info("Initialized email classifier with example data.")


def main():
    clear_model_data()
    initialize_classifier()
    st.set_page_config(page_title="Gmail Manager", layout="wide")
    st.title("📧 Gmail Manager")

    # Initialize Gmail service
    if 'service' not in st.session_state:
        with st.spinner('Connecting to Gmail...'):
            st.session_state.service = get_gmail_service()
    if "reply_text" not in st.session_state:
            st.session_state.reply_text = None

    service = st.session_state.service

    # Initialize expanded messages set in session state if not exists
    if 'expanded_messages' not in st.session_state:
        st.session_state.expanded_messages = set()

    # Sidebar controls
    with st.sidebar:
        st.header("📋 Controls")
        max_emails = st.slider("Number of emails to load", 5, 50, 10)
        refresh = st.button("🔄 Refresh Inbox")
        
        st.markdown("---")
        st.markdown("### 📊 Email Statistics")
        if 'messages' in st.session_state:
            st.info(f"Loaded emails: {len(st.session_state.messages)}")

    # Main email processing area
    if refresh or 'messages' not in st.session_state:
        with st.spinner('Loading emails...'):
            results = service.users().messages().list(
                userId='me', q='is:inbox', maxResults=max_emails).execute()
            st.session_state.messages = results.get('messages', [])

    if not st.session_state.messages:
        st.info("No emails found in inbox.")
        return

    # Process each email
    for idx, message in enumerate(st.session_state.messages):
        msg_id = message['id']
        email_data = get_message_data(service, msg_id)

        if not email_data:
            continue

        # Create expandable section for each email
        with st.expander(f"📨 {email_data.get('subject', 'No Subject')}"):
            # Email metadata
            col1, col2 = st.columns([2, 1])
            with col1:
                st.markdown(f"**From:** {email_data.get('from')}")
                st.markdown(f"**Date:** {email_data.get('date')}")
            with col2:
                category = categorize_email(email_data)
                st.markdown(f"**Category:** {category}")
                
                # Add feedback option for categorization
                st.write("Is this categorization correct?")
                feedback_col1, feedback_col2, feedback_col3 = st.columns(3)
                with feedback_col1:
                    if st.button("🔴 Urgent", key=f"urgent_{idx}"):
                        collect_training_data(email_data, "🔴 Urgent")
                        st.success("Thank you for your feedback!")
                with feedback_col2:
                    if st.button("🟡 Follow-up", key=f"followup_{idx}"):
                        collect_training_data(email_data, "🟡 Follow-up")
                        st.success("Thank you for your feedback!")
                with feedback_col3:
                    if st.button("🟢 Low Priority", key=f"low_{idx}"):
                        collect_training_data(email_data, "🟢 Low Priority")
                        st.success("Thank you for your feedback!")

            # Email content preview
            st.markdown("### Email Content:")
            st.text(email_data.get('body', 'No content available'))

            # Action buttons
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button("📝 Summarize", key=f"sum_{idx}"):
                    summarize_email_thread(service, message['threadId'])

            with col2:
                if st.button("⭐ Mark for Follow-up", key=f"mark_{idx}"):
                    label_id = get_or_create_label(service, "Needs Reply")
                    if label_id and add_label(service, msg_id, label_id):
                        st.success("Marked for follow-up!")

            with col3:
                if st.button("↩️ Quick Reply", key=f"reply_{idx}"):
                    st.write("Button clicked ")
                    suggestions = suggest_quick_replies(email_data)
                    st.session_state.reply_text = st.selectbox(
                        "Choose a reply:",
                        suggestions,
                        key=f"select_{idx}"
                    )
                    
                if st.session_state.reply_text:
                    
                    if st.button("Send", key=f"send_{idx}"):
                       
                        if send_reply(service, email_data['from'], 
                                   email_data['subject'], st.session_state.reply_text):
                            st.success("Reply sent successfully!")
                        else:
                            st.error("Failed to send email")
                        

            st.markdown("---")

if __name__ == '__main__':
    main()
