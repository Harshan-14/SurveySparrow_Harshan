import streamlit as st
import os
import subprocess
import sys

def main():
    # Page configuration
    st.set_page_config(
        page_title="Communication Hub",
        page_icon="🔌",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    # Header
    st.title("🔌 Communication Hub")
    st.markdown("### Your All-in-One Communication Management Platform")
    
    # Description
    st.markdown("""
    Welcome to Communication Hub! This platform integrates your essential communication channels 
    into one convenient dashboard. Select an application below to get started.
    """)
    
    # Create three columns for the app cards
    col1, col2, col3 = st.columns(3)
    
    # Gmail Card
    with col1:
        st.markdown("""
        <div style="padding: 20px; border-radius: 10px; border: 1px solid #ddd; text-align: center; height: 300px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
                <h2 style="color: #DB4437;">📧 Gmail Manager</h2>
                <p>Manage your emails efficiently with AI-powered categorization, quick replies, and more.</p>
                <p><b>Features:</b></p>
                <ul style="text-align: left;">
                    <li>Smart email categorization</li>
                    <li>AI-generated quick replies</li>
                    <li>Email summarization</li>
                </ul>
            </div>
        </div>
        """, unsafe_allow_html=True)
        if st.button("Launch Gmail Manager", key="gmail"):
            run_app("Gmail_new.py")
    
    # WhatsApp Card
    with col2:
        st.markdown("""
        <div style="padding: 20px; border-radius: 10px; border: 1px solid #ddd; text-align: center; height: 300px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
                <h2 style="color: #25D366;">💬 WhatsApp Analyzer</h2>
                <p>Analyze your WhatsApp chats to gain insights and visualize conversation patterns.</p>
                <p><b>Features:</b></p>
                <ul style="text-align: left;">
                    <li>Chat statistics and metrics</li>
                    <li>Message frequency analysis</li>
                    <li>Participant activity tracking</li>
                </ul>
            </div>
        </div>
        """, unsafe_allow_html=True)
        if st.button("Launch WhatsApp Analyzer", key="whatsapp"):
            run_app("WhatsApp.py")
    
    # Slack Card
    with col3:
        st.markdown("""
        <div style="padding: 20px; border-radius: 10px; border: 1px solid #ddd; text-align: center; height: 300px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
                <h2 style="color: #4A154B;">🔔 Slack Assistant</h2>
                <p>Stay on top of your Slack communications with smart notifications and organization.</p>
                <p><b>Features:</b></p>
                <ul style="text-align: left;">
                    <li>Channel monitoring</li>
                    <li>Priority message filtering</li>
                    <li>Automated responses</li>
                </ul>
            </div>
        </div>
        """, unsafe_allow_html=True)
        if st.button("Launch Slack Assistant", key="slack"):
            run_app("slack.py")
    
    # Footer
    st.markdown("---")
    st.markdown("© 2023 Communication Hub | Developed with ❤️ using Streamlit")

def run_app(app_name):
    """Run the selected application"""
    try:
        st.info(f"Launching {app_name}...")
        # Get the current script directory
        current_dir = os.path.dirname(os.path.abspath(__file__))
        app_path = os.path.join(current_dir, app_name)
        
        # Check if the file exists
        if not os.path.exists(app_path):
            st.error(f"Application file {app_name} not found at {app_path}")
            return
        
        # Run the application
        subprocess.Popen([sys.executable, "-m", "streamlit", "run", app_path])
        
        st.success(f"Launched {app_name} in a new window!")
        st.info("You can close this window or return to the homepage.")
        
    except Exception as e:
        st.error(f"Error launching {app_name}: {str(e)}")

if __name__ == "__main__":
    main()
