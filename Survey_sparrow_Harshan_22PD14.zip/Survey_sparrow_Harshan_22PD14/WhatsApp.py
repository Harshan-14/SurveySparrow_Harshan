import streamlit as st
import requests
import json
import os
import subprocess
import time
from datetime import datetime, timedelta
import pandas as pd
import plotly.express as px
import nltk
from twilio.rest import Client
from twilio.twiml.messaging_response import MessagingResponse
from flask import Flask, request, Response
import threading
import socket
import logging
import sys
import re
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from nltk.probability import FreqDist
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import io
import matplotlib.pyplot as plt
from wordcloud import WordCloud, STOPWORDS
from collections import Counter
from pyngrok import ngrok as pyngrok

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('WhatsAppBot')

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')

# Set page config
st.set_page_config(
    page_title="WhatsApp Business Bot",
    page_icon="💬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
    <style>
    .main {
        padding: 0rem 1rem;
    }
    .stButton>button {
        width: 100%;
        background-color: #25D366;
        color: white;
    }
    .status-box {
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 1rem 0;
    }
    .success {
        background-color: #dcf8c6;
        border: 1px solid #25D366;
    }
    .error {
        background-color: #ffe6e6;
        border: 1px solid #ff4d4d;
    }
    .log-container {
        height: 200px;
        overflow-y: auto;
        background-color: #f0f2f6;
        padding: 10px;
        border-radius: 5px;
        font-family: monospace;
        margin-bottom: 10px;
    }
    .chat-container {
        height: 400px;
        overflow-y: auto;
        background-color: #f0f2f6;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 10px;
    }
    .chat-message {
        padding: 8px 12px;
        border-radius: 10px;
        margin-bottom: 8px;
        max-width: 80%;
        word-wrap: break-word;
    }
    .chat-message.incoming {
        background-color: white;
        align-self: flex-start;
        margin-right: auto;
        border: 1px solid #e0e0e0;
    }
    .chat-message.outgoing {
        background-color: #dcf8c6;
        align-self: flex-end;
        margin-left: auto;
        border: 1px solid #c5e1a5;
    }
    .chat-header {
        font-weight: bold;
        margin-bottom: 4px;
    }
    .chat-time {
        font-size: 0.8em;
        color: #888;
        text-align: right;
    }
    </style>
""", unsafe_allow_html=True)

# Initialize session state
if 'messages' not in st.session_state:
    st.session_state.messages = []
if 'message_history' not in st.session_state:
    st.session_state.message_history = []
if 'twilio_account_sid' not in st.session_state:
    st.session_state.twilio_account_sid = ""
if 'twilio_auth_token' not in st.session_state:
    st.session_state.twilio_auth_token = ""
if 'twilio_phone_number' not in st.session_state:
    st.session_state.twilio_phone_number = ""
if 'twilio_initialized' not in st.session_state:
    st.session_state.twilio_initialized = False
if 'ngrok_running' not in st.session_state:
    st.session_state.ngrok_running = False
if 'ngrok_url' not in st.session_state:
    st.session_state.ngrok_url = ""
if 'webhook_logs' not in st.session_state:
    st.session_state.webhook_logs = []
if 'flask_app' not in st.session_state:
    st.session_state.flask_app = None
if 'flask_thread' not in st.session_state:
    st.session_state.flask_thread = None
if 'chat_data' not in st.session_state:
    st.session_state.chat_data = {}
if 'auto_reply_enabled' not in st.session_state:
    st.session_state.auto_reply_enabled = False
if 'auto_reply_message' not in st.session_state:
    st.session_state.auto_reply_message = "Thank you for your message! I'll get back to you soon."
if 'ngrok_process' not in st.session_state:
    st.session_state.ngrok_process = None

# Flask app for webhook handling
app = Flask(__name__)

@app.route("/webhook", methods=['POST'])
def webhook():
    """Handle incoming webhook requests from Twilio"""
    try:
        # Get the message data
        from_number = request.values.get('From', '')
        body = request.values.get('Body', '')
        
        # Log the incoming message
        log_message = f"Received message from {from_number}: {body}"
        logger.info(log_message)
        st.session_state.webhook_logs.append({
            'timestamp': datetime.now(),
            'message': log_message
        })
        
        # Add to message history
        st.session_state.message_history.append({
            'timestamp': datetime.now(),
            'direction': 'incoming',
            'phone_number': from_number,
            'message': body,
            'status': 'received'
        })
        
        # Process the message for auto-reply
        response_message = process_incoming_message(from_number, body)
        
        # Create a response
        resp = MessagingResponse()
        resp.message(response_message)
        
        return str(resp)
    except Exception as e:
        logger.error(f"Error in webhook: {str(e)}")
        return str(MessagingResponse())

def process_incoming_message(from_number, message):
    """Process incoming message and determine appropriate response"""
    # Check if auto-reply is enabled
    if st.session_state.auto_reply_enabled:
        return st.session_state.auto_reply_message
    
    # Check if it's a question about chat data
    if any(keyword in message.lower() for keyword in ["what", "who", "when", "how", "why", "?"]):
        # Try to answer the question based on chat data
        answer = answer_question_from_chat_data(message)
        if answer:
            return answer
    
    # Default response
    return "Thank you for your message! Our team will get back to you soon."

def answer_question_from_chat_data(question):
    """Answer a question based on available chat data"""
    if not st.session_state.chat_data:
        return None
    
    # Preprocess the question
    question = question.lower()
    
    # Check for specific question types
    if "who" in question and "active" in question:
        # Question about most active members
        try:
            most_active_chat = None
            max_messages = 0
            
            for chat_name, chat_df in st.session_state.chat_data.items():
                if len(chat_df) > max_messages:
                    most_active_chat = chat_name
                    max_messages = len(chat_df)
            
            if most_active_chat:
                author_counts = st.session_state.chat_data[most_active_chat]['Author'].value_counts()
                top_authors = author_counts.head(3)
                
                response = f"The most active members in {most_active_chat} are:\n"
                for author, count in top_authors.items():
                    response += f"- {author}: {count} messages\n"
                return response
        except Exception as e:
            logger.error(f"Error analyzing active members: {str(e)}")
    
    elif "summary" in question or "summarize" in question:
        # Question asking for a summary
        chat_name = None
        for name in st.session_state.chat_data.keys():
            if name.lower() in question.lower():
                chat_name = name
                break
        
        if chat_name:
            summary = generate_chat_summary(chat_name)
            return f"Summary of {chat_name}:\n\n{summary}"
        else:
            # If no specific chat mentioned, summarize the first one
            if st.session_state.chat_data:
                first_chat = list(st.session_state.chat_data.keys())[0]
                summary = generate_chat_summary(first_chat)
                return f"Summary of {first_chat}:\n\n{summary}"
    
    # For other types of questions, use a simple retrieval approach
    best_response = None
    best_score = 0
    
    for chat_name, chat_df in st.session_state.chat_data.items():
        # Create a corpus of messages
        corpus = chat_df['Message'].tolist()
        
        # Use TF-IDF to find the most relevant message
        vectorizer = TfidfVectorizer()
        try:
            tfidf_matrix = vectorizer.fit_transform(corpus + [question])
            
            # Calculate similarity between question and each message
            question_vector = tfidf_matrix[-1]
            message_vectors = tfidf_matrix[:-1]
            
            similarities = cosine_similarity(question_vector, message_vectors).flatten()
            
            # Get the most similar message
            if len(similarities) > 0:
                max_sim_idx = similarities.argmax()
                max_sim = similarities[max_sim_idx]
                
                if max_sim > best_score:
                    best_score = max_sim
                    author = chat_df.iloc[max_sim_idx]['Author']
                    message = chat_df.iloc[max_sim_idx]['Message']
                    best_response = f"Based on {chat_name}, {author} said: \"{message}\""
        except Exception as e:
            logger.error(f"Error in TF-IDF processing: {str(e)}")
    
    # Only return if we have a reasonably good match
    if best_score > 0.3:
        return best_response
    
    return None

def run_flask():
    """Run the Flask app in a separate thread"""
    try:
        app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)
    except Exception as e:
        logger.error(f"Flask error: {str(e)}")

def start_ngrok():
    """Start ngrok tunnel using pyngrok"""
    try:
        # Start ngrok
        public_url = pyngrok.connect(5000, "http")
        
        # Store the URL
        st.session_state.ngrok_url = public_url + "/webhook"
        st.session_state.ngrok_running = True
        
        return True, f"ngrok running at {st.session_state.ngrok_url}"
    except Exception as e:
        return False, f"Error starting ngrok: {str(e)}"

def stop_ngrok():
    """Stop all ngrok tunnels"""
    try:
        pyngrok.kill()
        st.session_state.ngrok_running = False
        st.session_state.ngrok_url = ""
        return True, "ngrok stopped"
    except Exception as e:
        return False, f"Error stopping ngrok: {str(e)}"

# Functions for Twilio API
def initialize_twilio_api(account_sid, auth_token, phone_number):
    """Initialize Twilio API credentials"""
    st.session_state.twilio_account_sid = account_sid
    st.session_state.twilio_auth_token = auth_token
    st.session_state.twilio_phone_number = phone_number
    st.session_state.twilio_initialized = True
    
    # Start Flask server if not already running
    if st.session_state.flask_thread is None or not st.session_state.flask_thread.is_alive():
        st.session_state.flask_thread = threading.Thread(target=run_flask, daemon=True)
        st.session_state.flask_thread.start()
    
    return True

def send_twilio_message(to_number, message):
    """Send a message using Twilio API"""
    # Check if Twilio is initialized
    if not st.session_state.twilio_initialized:
        return False, "Please initialize the Twilio API first"
    
    try:
        # Initialize Twilio client
        client = Client(st.session_state.twilio_account_sid, st.session_state.twilio_auth_token)
        
        # Format the phone number if needed
        if not to_number.startswith('+'):
            to_number = '+' + to_number
        
        # Send message
        twilio_message = client.messages.create(
            body=message,
            from_=st.session_state.twilio_phone_number,
            to=to_number
        )
        
        # Add to message history
        st.session_state.message_history.append({
            'timestamp': datetime.now(),
            'direction': 'outgoing',
            'phone_number': to_number,
            'message': message,
            'status': 'sent',
            'platform': 'Twilio',
            'message_sid': twilio_message.sid
        })
        
        return True, f"Message sent successfully! SID: {twilio_message.sid}"
    except Exception as e:
        return False, f"Error sending Twilio message: {str(e)}"

def fetch_twilio_messages():
    """Fetch message history from Twilio API"""
    if not st.session_state.twilio_initialized:
        return False, "Please initialize the Twilio API first"
    
    try:
        # Initialize Twilio client
        client = Client(st.session_state.twilio_account_sid, st.session_state.twilio_auth_token)
        
        # Get messages
        messages = client.messages.list(to=st.session_state.twilio_phone_number)
        
        # Add to message history
        new_messages = 0
        for msg in messages:
            # Check if message is already in history
            if not any(m.get('message_sid') == msg.sid for m in st.session_state.message_history):
                st.session_state.message_history.append({
                    'timestamp': datetime.fromisoformat(msg.date_created.isoformat()),
                    'direction': 'incoming',
                    'phone_number': msg.from_,
                    'message': msg.body,
                    'status': 'received',
                    'platform': 'Twilio',
                    'message_sid': msg.sid
                })
                new_messages += 1
        
        return True, f"Successfully fetched {new_messages} new messages"
    except Exception as e:
        return False, f"Error fetching Twilio messages: {str(e)}"

def analyze_message_history():
    """Analyze message history and return insights."""
    if not st.session_state.message_history:
        return None
    
    df = pd.DataFrame(st.session_state.message_history)
    
    # Basic statistics
    total_messages = len(df)
    outgoing_messages = len(df[df['direction'] == 'outgoing'])
    incoming_messages = len(df[df['direction'] == 'incoming'])
    unique_numbers = df['phone_number'].nunique()
    
    # Messages over time
    df['date'] = df['timestamp'].dt.date
    messages_per_day = df.groupby('date').size().reset_index(name='count')
    
    return {
        'total_messages': total_messages,
        'outgoing_messages': outgoing_messages,
        'incoming_messages': incoming_messages,
        'unique_numbers': unique_numbers,
        'messages_per_day': messages_per_day
    }

def analyze_date_distribution(df):
    """Analyze the distribution of dates in the DataFrame"""
    if 'Timestamp' not in df.columns or len(df) == 0:
        return "No timestamp data available"
    
    df['Date'] = df['Timestamp'].dt.date
    date_counts = df.groupby('Date').size()
    
    result = f"Date distribution:\n"
    result += f"- Total unique dates: {len(date_counts)}\n"
    result += f"- Date range: {df['Date'].min()} to {df['Date'].max()}\n"
    result += f"- Top 5 dates by message count:\n"
    
    for date, count in date_counts.nlargest(5).items():
        result += f"  * {date}: {count} messages\n"
    
    return result


# New functions for chat analysis and summarization
def parse_whatsapp_chat(file):
    """Parse WhatsApp chat export file with improved error handling"""
    try:
        content = file.getvalue().decode("utf-8")
        
        # Print first few lines for debugging
        first_lines = '\n'.join(content.split('\n')[:5])
        st.info(f"Sample of chat file:\n\n```\n{first_lines}\n```")
        
        # Define regex pattern for WhatsApp chat messages
        pattern = r'(\d{1,2}/\d{1,2}/\d{2,4},\s\d{1,2}:\d{2}(?::\d{2})?\s(?:AM|PM)?)?\s-\s([^:]+):\s([\s\S]*?)(?=\d{1,2}/\d{1,2}/\d{2,4},\s\d{1,2}:\d{2}(?::\d{2})?\s(?:AM|PM)?\s-\s|$)'
        
        # Extract messages
        matches = re.findall(pattern, content)
        
        if not matches:
            st.error("No messages found matching the expected WhatsApp format. Please ensure this is a valid WhatsApp chat export.")
            st.info("Expected format: 'MM/DD/YY, HH:MM AM/PM - Author Name: Message content'")
            return pd.DataFrame(columns=['Timestamp', 'Author', 'Message'])
        
        # Create DataFrame
        data = []
        for match in matches:
            timestamp_str, author, message = match
            
            # Skip system messages
            if "added" in author or "removed" in author or "left" in author or "joined" in author:
                continue
                
            # Try to parse timestamp
            timestamp = None
            try:
                # Handle different date formats
                if '/' in timestamp_str:
                    # Try multiple date formats
                    date_formats = [
                        "%d/%m/%y, %I:%M:%S %p",  # DD/MM/YY, HH:MM:SS AM/PM
                        "%d/%m/%Y, %I:%M:%S %p",  # DD/MM/YYYY, HH:MM:SS AM/PM
                        "%d/%m/%y, %I:%M %p",     # DD/MM/YY, HH:MM AM/PM
                        "%d/%m/%Y, %I:%M %p",     # DD/MM/YYYY, HH:MM AM/PM
                        "%m/%d/%y, %I:%M:%S %p",  # MM/DD/YY, HH:MM:SS AM/PM
                        "%m/%d/%Y, %I:%M:%S %p",  # MM/DD/YYYY, HH:MM:SS AM/PM
                        "%m/%d/%y, %I:%M %p",     # MM/DD/YY, HH:MM AM/PM
                        "%m/%d/%Y, %I:%M %p",     # MM/DD/YYYY, HH:MM AM/PM
                    ]
                    
                    for fmt in date_formats:
                        try:
                            timestamp = datetime.strptime(timestamp_str, fmt)
                            break
                        except ValueError:
                            continue
                    
                    if timestamp is None:
                        # If all parsing fails, use current time
                        timestamp = datetime.now()
                        st.warning(f"Could not parse date: {timestamp_str}. Using current time instead.")
                else:
                    timestamp = datetime.now()
            except Exception as e:
                # If all parsing fails, use current time
                timestamp = datetime.now()
                st.warning(f"Error parsing date: {str(e)}. Using current time instead.")
            
            # Clean author name
            author = author.strip()
            
            data.append({
                'Timestamp': timestamp,
                'Author': author,
                'Message': message.strip()
            })
        
        # Create DataFrame
        df = pd.DataFrame(data)
        
        if len(df) == 0:
            st.warning("No valid messages found in the chat export. Please check the file format.")
            return pd.DataFrame(columns=['Timestamp', 'Author', 'Message'])
        
        # Debug information
        st.info(f"Date range in parsed data: {df['Timestamp'].min()} to {df['Timestamp'].max()}")
        
        return df
    
    except Exception as e:
        st.error(f"Error parsing chat file: {str(e)}")
        st.info("Please ensure you're uploading a valid WhatsApp chat export file.")
        return pd.DataFrame(columns=['Timestamp', 'Author', 'Message'])

def generate_chat_summary(chat_name):
    """Generate a summary of the chat"""
    if chat_name not in st.session_state.chat_data:
        return "Chat data not found."
    
    df = st.session_state.chat_data[chat_name]
    
    if len(df) == 0 or 'Author' not in df.columns:
        return "No valid chat data available for analysis."
    
    # Basic statistics
    total_messages = len(df)
    unique_authors = df['Author'].nunique()
    author_counts = df['Author'].value_counts()
    top_authors = author_counts.head(5)
    
    # Time analysis
    df['Date'] = df['Timestamp'].dt.date
    messages_per_day = df.groupby('Date').size()
    
    if len(messages_per_day) > 0:
        most_active_day = messages_per_day.idxmax()
        most_messages_in_day = messages_per_day.max()
    else:
        most_active_day = "N/A"
        most_messages_in_day = 0
    
    # Content analysis
    all_messages = ' '.join(df['Message'].tolist())
    words = word_tokenize(all_messages.lower())
    stop_words = set(stopwords.words('english'))
    filtered_words = [word for word in words if word.isalnum() and word not in stop_words]
    
    # Most common words
    word_freq = Counter(filtered_words)
    common_words = word_freq.most_common(10)
    
    # Build summary
    summary = f"Chat Summary for {chat_name}:\n\n"
    summary += f"Total Messages: {total_messages}\n"
    summary += f"Unique Participants: {unique_authors}\n\n"
    
    summary += "Top Participants:\n"
    for author, count in top_authors.items():
        percentage = (count / total_messages) * 100
        summary += f"- {author}: {count} messages ({percentage:.1f}%)\n"
    
    summary += f"\nMost Active Day: {most_active_day} with {most_messages_in_day} messages\n\n"
    
    summary += "Most Common Words:\n"
    for word, count in common_words:
        summary += f"- {word}: {count} times\n"
    
    return summary



def create_word_cloud(chat_name):
    """Create a word cloud from chat messages"""
    if chat_name not in st.session_state.chat_data:
        return None
    
    df = st.session_state.chat_data[chat_name]
    
    if len(df) == 0 or 'Message' not in df.columns:
        return None
    
    # Combine all messages
    all_messages = ' '.join(df['Message'].tolist())
    
    # Create word cloud
    wordcloud = WordCloud(
        width=800, 
        height=400, 
        background_color='white',
        stopwords=set(STOPWORDS),
        max_words=100
    ).generate(all_messages)
    
    # Create figure
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.imshow(wordcloud, interpolation='bilinear')
    ax.axis('off')
    plt.tight_layout()
    
    return fig

def analyze_chat_sentiment(chat_name):
    """Analyze sentiment in chat messages"""
    if chat_name not in st.session_state.chat_data:
        return None
    
    df = st.session_state.chat_data[chat_name]
    
    if len(df) == 0:
        return None
    
    # This is a placeholder for sentiment analysis
    # In a real implementation, you would use a sentiment analysis library
    # such as TextBlob, VADER, or a more sophisticated model
    
    # For now, we'll return a random distribution
    sentiments = ['Positive', 'Neutral', 'Negative']
    values = [np.random.randint(40, 60), np.random.randint(20, 40), np.random.randint(10, 30)]
    
    fig = px.pie(
        values=values,
        names=sentiments,
        title=f'Message Sentiment in {chat_name}',
        color=sentiments,
        color_discrete_map={'Positive': '#25D366', 'Neutral': '#34B7F1', 'Negative': '#FF6B6B'}
    )
    
    return fig

def main():
    st.title("WhatsApp Business Bot Dashboard 💬")
    
    # Sidebar configuration
    st.sidebar.header("Configuration")
    
    # Twilio API Credentials
    st.sidebar.subheader("Twilio API Credentials")
    account_sid = st.sidebar.text_input(
        "Account SID",
        value=st.session_state.twilio_account_sid,
        type="password"
    )
    auth_token = st.sidebar.text_input(
        "Auth Token",
        value=st.session_state.twilio_auth_token,
        type="password"
    )
    phone_number = st.sidebar.text_input(
        "Twilio Phone Number",
        value=st.session_state.twilio_phone_number,
        placeholder="e.g., +14155238886"
    )
    
    if st.sidebar.button("Initialize Twilio API"):
        if account_sid and auth_token and phone_number:
            if initialize_twilio_api(account_sid, auth_token, phone_number):
                st.sidebar.success("Twilio API initialized successfully!")
        else:
            st.sidebar.error("Please provide all Twilio credentials")
    
    # Display Twilio API status
    if st.session_state.twilio_initialized:
        st.sidebar.markdown("**Twilio API Status:** 🟢 Initialized")
    else:
        st.sidebar.markdown("**Twilio API Status:** 🔴 Not Initialized")
    
    # ngrok configuration
    st.sidebar.subheader("Webhook Configuration")
    
    if st.session_state.ngrok_running:
        st.sidebar.markdown(f"**ngrok Status:** 🟢 Running")
        st.sidebar.markdown(f"**Webhook URL:** {st.session_state.ngrok_url}")
        
        if st.sidebar.button("Stop ngrok"):
            success, message = stop_ngrok()
            if success:
                st.sidebar.success(message)
                st.experimental_rerun()
            else:
                st.sidebar.error(message)
    else:
        st.sidebar.markdown("**ngrok Status:** 🔴 Not Running")
        
        if st.sidebar.button("Start ngrok"):
            success, message = start_ngrok()
            if success:
                st.sidebar.success(message)
                st.sidebar.markdown(f"**Webhook URL:** {st.session_state.ngrok_url}")
                st.sidebar.info("Copy this URL to your Twilio WhatsApp Sandbox configuration")
            else:
                st.sidebar.error(message)
    
    # Auto-reply configuration
    st.sidebar.subheader("Auto-Reply Settings")
    auto_reply_enabled = st.sidebar.checkbox("Enable Auto-Reply", value=st.session_state.auto_reply_enabled)
    auto_reply_message = st.sidebar.text_area(
        "Auto-Reply Message", 
        value=st.session_state.auto_reply_message,
        height=100
    )
    
    if auto_reply_enabled != st.session_state.auto_reply_enabled or auto_reply_message != st.session_state.auto_reply_message:
        st.session_state.auto_reply_enabled = auto_reply_enabled
        st.session_state.auto_reply_message = auto_reply_message
        st.sidebar.success("Auto-reply settings updated!")
    
    # Main content area
    tabs = st.tabs([
        "Send Messages", 
        "Webhook Logs", 
        "Message History", 
        "Chat Analysis",
        "Chat Q&A",
        "Analytics"
    ])
    
    # Send Messages Tab
    with tabs[0]:
        st.header("Send Messages")
        
        # Check if Twilio is initialized
        if not st.session_state.twilio_initialized:
            st.warning("Please initialize the Twilio API first")
        
        phone_number = st.text_input("Phone Number (with country code)", placeholder="e.g., +919361425899")
        message = st.text_area("Message", placeholder="Type your message here...")
        
        send_button = st.button("Send Message")
        if send_button:
            if not st.session_state.twilio_initialized:
                st.error("Please initialize the Twilio API first")
            elif phone_number and message:
                success, response = send_twilio_message(phone_number, message)
                if success:
                    st.success(response)
                else:
                    st.error(response)
            else:
                st.warning("Please provide both phone number and message")
    
    # Webhook Logs Tab
    with tabs[1]:
        st.header("Webhook Logs")

        if st.session_state.ngrok_running:
            st.success(f"Webhook active at: {st.session_state.ngrok_url}")

            with st.expander("Twilio Configuration Instructions"):
                st.markdown(f"""
                ### How to configure your Twilio WhatsApp Sandbox:
                
                1. Go to your [Twilio Console](https://www.twilio.com/console/sms/whatsapp/sandbox)
                2. Find the "When a message comes in" field
                3. Enter your ngrok URL: `{st.session_state.ngrok_url}`
                4. Click Save
                
                Now, when someone sends a message to your Twilio WhatsApp number, it will be forwarded to this application.
                """)
            
            # Display webhook logs
            st.subheader("Recent Webhook Logs")
            
            if st.session_state.webhook_logs:
                # Create a log container
                log_container = st.container()
                
                with log_container:
                    st.markdown('<div class="log-container">', unsafe_allow_html=True)
                    for log in reversed(st.session_state.webhook_logs[-20:]):  # Show last 20 logs
                        timestamp = log['timestamp'].strftime('%Y-%m-%d %H:%M:%S')
                        st.text(f"[{timestamp}] {log['message']}")
                    st.markdown('</div>', unsafe_allow_html=True)
                
                if st.button("Clear Logs"):
                    st.session_state.webhook_logs = []
                    st.experimental_rerun()
            else:
                st.info("No webhook logs yet. Send a message to your Twilio WhatsApp number to see logs here.")
        else:
            st.warning("Webhook is not active. Start ngrok to enable webhook functionality.")
            st.info("Click 'Start ngrok' in the sidebar to create a public URL for your webhook.")
        
        # manually fetch messages from Twilio API
        st.subheader("Manual Message Fetch")
        if st.button("Fetch Messages from Twilio"):
            if st.session_state.twilio_initialized:
                success, message = fetch_twilio_messages()
                if success:
                    st.success(message)
                else:
                    st.error(message)
            else:
                st.error("Please initialize the Twilio API first")
    
    # Message History Tab
    with tabs[2]:
        st.header("Message History")
        
        if st.session_state.message_history:
            # Convert to DataFrame for display
            df = pd.DataFrame(st.session_state.message_history)
            
            # Format timestamp for better display
            if 'timestamp' in df.columns:
                df['formatted_time'] = df['timestamp'].dt.strftime('%Y-%m-%d %H:%M:%S')
            
            # Select columns to display
            display_cols = ['formatted_time', 'direction', 'phone_number', 'message', 'status']
                
            display_df = df[display_cols] if all(col in df.columns for col in display_cols) else df
            
            st.dataframe(display_df, use_container_width=True)
            
            # Export options
            col1, col2 = st.columns(2)
            with col1:
                if st.button("Clear History"):
                    st.session_state.message_history = []
                    st.experimental_rerun()
            with col2:
                if st.button("Export as CSV"):
                    csv = df.to_csv(index=False)
                    st.download_button(
                        label="Download CSV",
                        data=csv,
                        file_name="whatsapp_message_history.csv",
                        mime="text/csv"
                    )
        else:
            st.info("No messages in history")
    
        # Chat Analysis Tab
    with tabs[3]:
        st.header("Chat Analysis")
        
        # Upload WhatsApp chat export
        st.subheader("Upload WhatsApp Chat Export")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            chat_file = st.file_uploader("Upload WhatsApp chat export (.txt file)", type=["txt"])
        
        with col2:
            chat_name = st.text_input("Chat Name", placeholder="e.g., Family Group")
            # Add input for number of days to analyze
            days_to_analyze = st.text_input("Number of days to analyze (leave empty for all)", placeholder="e.g., 30")
            upload_button = st.button("Upload and Analyze")
        
        if upload_button and chat_file and chat_name:
            try:
                # Parse chat file
                df = parse_whatsapp_chat(chat_file)
                
                # Show date distribution
                if len(df) > 0 and 'Timestamp' in df.columns:
                    date_analysis = analyze_date_distribution(df)
                    st.info(date_analysis)
                
                # Filter by days if specified
                if days_to_analyze and days_to_analyze.isdigit():
                    days = int(days_to_analyze)
                    cutoff_date = datetime.now() - timedelta(days=days)
                    original_count = len(df)
                    df = df[df['Timestamp'] >= cutoff_date]
                    st.info(f"Filtering to last {days} days (from {cutoff_date.date()} to present). Kept {len(df)} of {original_count} messages.")
                
                # Store in session state
                st.session_state.chat_data[chat_name] = df
                
                st.success(f"Successfully uploaded and analyzed {chat_name} with {len(df)} messages!")
            except Exception as e:
                st.error(f"Error parsing chat file: {str(e)}")
        
        # Display chat analysis if available
        if st.session_state.chat_data:
            st.subheader("Chat Analysis")
            
            # Select chat to analyze
            selected_chat = st.selectbox(
                "Select Chat to Analyze",
                options=list(st.session_state.chat_data.keys())
            )
            
            if selected_chat:
                df = st.session_state.chat_data[selected_chat]
                
                if len(df) > 0 and 'Author' in df.columns:
                    # Basic statistics
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Total Messages", len(df))
                    with col2:
                        st.metric("Participants", df['Author'].nunique())
                    with col3:
                        st.metric("Date Range", f"{df['Timestamp'].min().date()} to {df['Timestamp'].max().date()}")
                    
                    # Message activity over time
                    st.subheader("Message Activity Over Time")
                    df['Date'] = df['Timestamp'].dt.date
                    messages_per_day = df.groupby('Date').size().reset_index(name='Messages')
                    
                    # Debug information
                    st.info(f"Number of unique dates: {len(messages_per_day)}")
                    
                    fig = px.line(
                        messages_per_day,
                        x='Date',
                        y='Messages',
                        title=f'Message Activity in {selected_chat}'
                    )
                    # Ensure the x-axis shows all dates
                    fig.update_xaxes(
                        tickmode='auto',
                        nticks=min(30, len(messages_per_day))  # Limit to 30 ticks max
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Top participants
                    st.subheader("Top Participants")
                    author_counts = df['Author'].value_counts().reset_index()
                    author_counts.columns = ['Author', 'Messages']
                    author_counts = author_counts.head(10)
                    
                    fig = px.bar(
                        author_counts,
                        x='Author',
                        y='Messages',
                        title=f'Most Active Participants in {selected_chat}'
                    )
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Word cloud
                    st.subheader("Word Cloud")
                    word_cloud_fig = create_word_cloud(selected_chat)
                    if word_cloud_fig:
                        st.pyplot(word_cloud_fig)
                    
                    # Chat summary
                    st.subheader("Chat Summary")
                    summary = generate_chat_summary(selected_chat)
                    st.text_area("Summary", value=summary, height=300, disabled=True)
                    
                    # Sentiment analysis
                    st.subheader("Sentiment Analysis")
                    sentiment_fig = analyze_chat_sentiment(selected_chat)
                    if sentiment_fig:
                        st.plotly_chart(sentiment_fig, use_container_width=True)
                else:
                    st.error("The selected chat data is invalid or empty.")

    # Chat Q&A Tab
    with tabs[4]:
        st.header("Chat Q&A")
        
        if not st.session_state.chat_data:
            st.warning("Please upload at least one chat export in the Chat Analysis tab first.")
        else:
            st.info("Ask questions about your WhatsApp chats. For example: 'Who is the most active member in my family group?' or 'Summarize the project discussion'")
            
            question = st.text_input("Your Question", placeholder="Ask something about your chats...")
            
            if st.button("Get Answer"):
                if question:
                    answer = answer_question_from_chat_data(question)
                    if answer:
                        st.success("Answer found!")
                        st.markdown(f"**Answer:** {answer}")
                    else:
                        st.error("Sorry, I couldn't find an answer to that question based on your chat data.")
                else:
                    st.warning("Please enter a question.")
            
            # Example questions
            with st.expander("Example Questions"):
                st.markdown("""
                - Who is the most active member in the chat?
                - Summarize the chat
                - What are the most common topics discussed?
                - When was the chat most active?
                - What did [person name] say about [topic]?
                """)
    
    # Analytics Tab
    with tabs[5]:
        st.header("Analytics")
        
        insights = analyze_message_history()
        if insights:
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Messages", insights['total_messages'])
            with col2:
                st.metric("Outgoing Messages", insights['outgoing_messages'])
            with col3:
                st.metric("Incoming Messages", insights['incoming_messages'])
            with col4:
                st.metric("Unique Numbers", insights['unique_numbers'])
            
            # Messages over time chart
            st.subheader("Messages Over Time")
            fig = px.line(
                insights['messages_per_day'],
                x='date',
                y='count',
                title='Message Volume Over Time'
            )
            st.plotly_chart(fig, use_container_width=True)
            
            # Direction distribution
            direction_counts = pd.DataFrame({
                'direction': ['Outgoing', 'Incoming'],
                'count': [insights['outgoing_messages'], insights['incoming_messages']]
            })
            
            st.subheader("Message Direction")
            fig3 = px.bar(
                direction_counts,
                x='direction',
                y='count',
                color='direction',
                title='Outgoing vs Incoming Messages'
            )
            st.plotly_chart(fig3, use_container_width=True)
        else:
            st.info("No data available for analysis")

if __name__ == "__main__":
    main()