import streamlit as st
import os
import slack_sdk
from slack_sdk.errors import SlackApiError
import datetime
from collections import defaultdict
import heapq
import re
import time
import sys
import subprocess
import tempfile
import gc
import pickle

# Force all temporary files to D drive
temp_dir = "D:/temp_files"
os.makedirs(temp_dir, exist_ok=True)
tempfile.tempdir = temp_dir
os.environ['TMPDIR'] = temp_dir
os.environ['TEMP'] = temp_dir
os.environ['TMP'] = temp_dir

# Configure all cache directories to use D drive
cache_dir = "D:/app_cache"
os.makedirs(cache_dir, exist_ok=True)
os.environ['TRANSFORMERS_CACHE'] = 'D:/huggingface_cache'
os.environ['HF_HOME'] = 'D:/huggingface_home'
os.environ['XDG_CACHE_HOME'] = 'D:/xdg_cache'
os.environ['TORCH_HOME'] = 'D:/torch_home'
os.environ['HUGGINGFACE_HUB_CACHE'] = 'D:/hf_hub_cache'

# Configure NLTK data path to use D drive
nltk_data_path = "D:/nltk_data"
os.makedirs(nltk_data_path, exist_ok=True)

# Configure pip to use D drive
pip_target = "D:/pip_packages"
os.makedirs(pip_target, exist_ok=True)
os.environ['PIP_TARGET'] = pip_target
if pip_target not in sys.path:
    sys.path.insert(0, pip_target)

# Import NLTK after setting paths
import nltk
nltk.data.path = [nltk_data_path]  # Override the default paths completely

# Set page config
st.set_page_config(page_title="Slack Message Analyzer", page_icon="💬", layout="wide")

# Add custom CSS
st.markdown("""
    <style>
    .stButton>button {
        width: 100%;
        background-color: #4CAF50;
        color: white;
    }
    .stTextInput>div>div>input {
        background-color: #f0f2f6;
    }
    </style>
    """, unsafe_allow_html=True)

# Initialize session state
if 'messages' not in st.session_state:
    st.session_state.messages = []
if 'summary' not in st.session_state:
    st.session_state.summary = ""
if 'daily_digest' not in st.session_state:
    st.session_state.daily_digest = {}
if 'actionable_messages' not in st.session_state:
    st.session_state.actionable_messages = []
if 'search_results' not in st.session_state:
    st.session_state.search_results = []
if 'slack_token' not in st.session_state:
    st.session_state.slack_token = "xoxb-8497644507667-8496429726197-04SJ6IJnGRAlsjvzh2AYRTcg"
if 'tasks' not in st.session_state:
    st.session_state.tasks = []

def clear_memory():
    """Force garbage collection to free memory"""
    gc.collect()

def save_state():
    """Save session state to disk to prevent data loss"""
    try:
        with open("D:/slack_app_state.pkl", "wb") as f:
            pickle.dump({
                'summary': st.session_state.summary,
                'tasks': st.session_state.tasks,
                'search_results': st.session_state.search_results
            }, f)
    except Exception:
        pass

def load_state():
    """Load session state from disk"""
    try:
        if os.path.exists("D:/slack_app_state.pkl"):
            with open("D:/slack_app_state.pkl", "rb") as f:
                state = pickle.load(f)
                st.session_state.summary = state.get('summary', "")
                st.session_state.tasks = state.get('tasks', [])
                st.session_state.search_results = state.get('search_results', [])
    except Exception:
        pass

def setup_nltk():
    """Download required NLTK resources to D drive"""
    try:
        with st.spinner('Downloading NLTK resources to D drive...'):
            nltk.download('punkt', download_dir=nltk_data_path)
            nltk.download('stopwords', download_dir=nltk_data_path)
        st.success(f"Successfully downloaded NLTK resources to {nltk_data_path}")
    except Exception as e:
        st.error(f"Error downloading NLTK resources: {e}")

def initialize_slack_client():
    """Initialize Slack client with token"""
    return slack_sdk.WebClient(token=st.session_state.slack_token)

def simple_sentence_tokenize(text):
    """Simple sentence tokenization using regular expressions"""
    sentences = re.split(r'[.!?]+', text)
    return [s.strip() for s in sentences if s.strip()]

def list_channels(client):
    """Lists all channels the bot has access to."""
    try:
        result = client.conversations_list()
        channels = result["channels"]
        return channels
    except SlackApiError as e:
        st.error(f"Error listing channels: {e}")
        return []

def get_channel_messages(client, channel_id, days=1):
    """Fetches messages from a Slack channel for a specified number of days."""
    now = datetime.datetime.now()
    oldest = (now - datetime.timedelta(days=days)).timestamp()

    try:
        result = client.conversations_history(channel=channel_id, oldest=oldest)
        return result.get('messages', [])
    except SlackApiError as e:
        st.error(f"Error fetching messages from channel {channel_id}: {e}")
        return []

def summarize_conversation(messages, num_sentences=3):
    """Summarizes a conversation using simple text analysis."""
    if not messages:
        return "No messages to summarize."

    # Process in batches to avoid memory issues
    batch_size = 50
    all_text = ""
    
    for i in range(0, len(messages), batch_size):
        batch = messages[i:i+batch_size]
        batch_text = " ".join([msg.get('text', '') for msg in batch])
        all_text += " " + batch_text
        
        # Free memory after each batch
        batch = None
        batch_text = None
        clear_memory()
    
    # Text Cleaning
    text = re.sub(r'\[[0-9]*\]', ' ', all_text)
    text = re.sub(r'\s+', ' ', text)

    # Simple sentence tokenization
    sentence_list = simple_sentence_tokenize(text)

    if not sentence_list:
        return "No valid sentences to summarize."

    # Simple word frequency analysis
    words = re.findall(r'\w+', text.lower())
    word_freq = {}
    for word in words:
        if word not in word_freq:
            word_freq[word] = 1
        else:
            word_freq[word] += 1
    
    # Simple stop words
    stop_words = set(['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 
                      'the', 'a', 'an', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 
                      'while', 'of', 'at', 'by', 'for', 'with', 'about', 'against', 'between', 
                      'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 
                      'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 
                      'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 
                      'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 
                      'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 
                      't', 'can', 'will', 'just', 'don', 'should', 'now'])

    # Score sentences
    sentence_scores = {}
    for sentence in sentence_list:
        for word in re.findall(r'\w+', sentence.lower()):
            if word not in stop_words and word in word_freq:
                if len(sentence.split(' ')) < 30:  # Avoid very long sentences
                    if sentence not in sentence_scores:
                        sentence_scores[sentence] = word_freq[word]
                    else:
                        sentence_scores[sentence] += word_freq[word]

    # Get top sentences
    summary_sentences = heapq.nlargest(min(num_sentences, len(sentence_scores)), 
                                     sentence_scores, key=sentence_scores.get)
    
    # Clean up memory
    text = None
    sentence_list = None
    words = None
    word_freq = None
    sentence_scores = None
    clear_memory()
    
    return " ".join(summary_sentences)

def identify_actionable_messages(messages):
    """
    Identifies actionable messages using keyword-based approach.
    """
    # Use a more memory-efficient approach
    actionable = []
    tasks = []
    
    # Keywords for task identification
    keywords = ["action", "task", "todo", "reminder", "deadline", "important", 
                "please", "asap", "urgent", "need", "required", "by tomorrow",
                "by monday", "by tuesday", "by wednesday", "by thursday", 
                "by friday", "by saturday", "by sunday", "follow up"]
    
    # Process messages in batches to avoid memory issues
    for i in range(0, len(messages), 10):
        batch = messages[i:i+10]
        
        for msg in batch:
            text = msg.get('text', '').lower()
            if not text or len(text) < 5:
                continue
            
            # Check if message contains action keywords
            if any(keyword in text for keyword in keywords):
                actionable.append(msg)
                
                # Create a task entry
                matching_keywords = [kw for kw in keywords if kw in text]
                task = {
                    'text': msg.get('text', ''),
                    'confidence': 0.8,
                    'category': matching_keywords[0] if matching_keywords else "task",
                    'user': msg.get('user', 'Unknown'),
                    'timestamp': msg.get('ts', '')
                }
                tasks.append(task)
        
        # Add a small delay to prevent resource exhaustion
        time.sleep(0.1)
    
    # Store tasks in session state
    st.session_state.tasks = tasks
    
    # Clean up memory
    clear_memory()
    
    return actionable

def smart_search(client, query, channel_ids, days=7):
    """Performs a smart search across channels."""
    results = []
    
    for channel_id in channel_ids:
        try:
            now = datetime.datetime.now()
            oldest = (now - datetime.timedelta(days=days)).timestamp()
            
            # Process in smaller batches
            response = client.conversations_history(
                channel=channel_id,
                oldest=oldest,
                limit=100  # Limit to 100 messages per request
            )
            
            messages = response.get('messages', [])
            matches = [
                msg for msg in messages 
                if query.lower() in msg.get('text', '').lower()
            ]
            
            for msg in matches:
                msg['channel_id'] = channel_id
                try:
                    # Get channel name
                    channel_info = client.conversations_info(channel=channel_id)
                    msg['channel_name'] = channel_info['channel']['name']
                    
                    # Get user info
                    if 'user' in msg:
                        user_info = client.users_info(user=msg['user'])
                        msg['username'] = user_info['user']['real_name']
                    else:
                        msg['username'] = "Unknown User"
                        
                    # Clean up message text
                    text = msg.get('text', '')
                    # Remove URL formatting
                    text = re.sub(r'<(https?://[^|>]+)\|([^>]+)>', r'\2', text)
                    # Remove other Slack formatting
                    text = re.sub(r'<([^>]+)>', r'\1', text)
                    msg['cleaned_text'] = text
                    
                except Exception as e:
                    st.error(f"Error processing message: {e}")
                    msg['username'] = "Unknown User"
                    msg['cleaned_text'] = msg.get('text', '')

            results.extend(matches)
            
            # Clean up memory after each channel
            messages = None
            matches = None
            clear_memory()
            
        except SlackApiError as e:
            st.error(f"Error searching channel {channel_id}: {e}")
    
    return results

def display_search_results(results):
    """Displays search results in a formatted way."""
    if results:
        st.success(f"Found {len(results)} results!")
        
        # Display only first 20 results to avoid overload
        display_limit = min(20, len(results))
        if len(results) > 20:
            st.warning(f"Showing first {display_limit} of {len(results)} results to avoid performance issues.")
        
        for i, result in enumerate(results[:display_limit]):
            with st.expander(f"Message from {result.get('channel_name', 'Unknown Channel')}"):
                st.markdown(f"**Message:** {result.get('cleaned_text', 'No text')}")
                # Convert timestamp to readable format
                ts = float(result.get('ts', 0))
                dt = datetime.datetime.fromtimestamp(ts)
                st.markdown(f"**Time:** {dt.strftime('%Y-%m-%d %H:%M:%S')}")
                st.markdown(f"**From:** {result.get('username', 'Unknown User')}")
    else:
        st.info("No results found")

def display_todo_list(client):
    """Displays the extracted tasks as a to-do list."""
    if 'tasks' not in st.session_state or not st.session_state.tasks:
        st.info("No tasks identified yet.")
        return
    
    st.markdown("### 📋 To-Do List")
    
    # Sort tasks by confidence score
    tasks = sorted(st.session_state.tasks, key=lambda x: x['confidence'], reverse=True)
    
    # Limit display to avoid performance issues
    display_limit = min(20, len(tasks))
    if len(tasks) > 20:
        st.warning(f"Showing first {display_limit} of {len(tasks)} tasks to avoid performance issues.")
    
    for i, task in enumerate(tasks[:display_limit]):
        # Get user info
        username = "Unknown User"
        if task['user'] != 'Unknown':
            try:
                user_info = client.users_info(user=task['user'])
                username = user_info['user']['real_name']
            except:
                pass
        
        # Convert timestamp to readable format
        time_str = ""
        if task['timestamp']:
            try:
                ts = float(task['timestamp'])
                dt = datetime.datetime.fromtimestamp(ts)
                time_str = dt.strftime('%Y-%m-%d %H:%M')
            except:
                pass
        
        # Display task with checkbox
        col1, col2 = st.columns([0.9, 0.1])
        with col1:
            with st.expander(f"Task {i+1}: {task['text'][:50]}..." if len(task['text']) > 50 else f"Task {i+1}: {task['text']}"):
                st.markdown(f"**Task:** {task['text']}")
                st.markdown(f"**Category:** {task['category']}")
                st.markdown(f"**Confidence:** {task['confidence']:.2f}")
                st.markdown(f"**Assigned by:** {username}")
                if time_str:
                    st.markdown(f"**Posted on:** {time_str}")
        with col2:
            st.checkbox("Done", key=f"task_{i}")

def install_transformers():
    """Install transformers library to D drive"""
    try:
        # Create pip target directory on D drive
        os.makedirs(pip_target, exist_ok=True)
        
        # Set environment variable for pip
        os.environ['PIP_TARGET'] = pip_target
        
        # Add to Python path
        if pip_target not in sys.path:
            sys.path.insert(0, pip_target)
            
        with st.spinner("Installing transformers library to D drive..."):
            subprocess.check_call([
                sys.executable, 
                "-m", 
                "pip", 
                "install", 
                "--target=" + pip_target,
                "--cache-dir=D:/pip_cache",
                "--no-cache-dir",  # Force fresh install
                "transformers", 
                "torch"
            ])
            
        st.success(f"Transformers installed successfully to {pip_target}!")
        return True
    except Exception as e:
        st.error(f"Error installing transformers: {e}")
        return False

def main():
    st.title("Slack Message Analyzer 💬")
    
    # Try to load saved state
    load_state()
    
    # Display storage locations
    with st.expander("Storage Locations (All on D Drive)"):
        st.markdown(f"**NLTK Data:** {nltk_data_path}")
        st.markdown(f"**Pip Packages:** {pip_target}")
        st.markdown(f"**Temporary Files:** {temp_dir}")
        st.markdown(f"**Transformers Cache:** {os.environ['TRANSFORMERS_CACHE']}")
        st.markdown(f"**Hugging Face Home:** {os.environ['HF_HOME']}")
    
    # Sidebar for token input
    st.sidebar.title("Configuration")
    new_token = st.sidebar.text_input("Slack Bot Token:", value=st.session_state.slack_token, type="password")
    if new_token != st.session_state.slack_token:
        st.session_state.slack_token = new_token
    
    # Initialize Slack client
    client = initialize_slack_client()

    # Setup NLTK
    if st.sidebar.button("Setup NLTK Resources"):
        setup_nltk()
        
    # Install transformers if needed
    if st.sidebar.button("Install Transformers to D Drive"):
        install_transformers()

    # Channel selection
    st.sidebar.title("Channel Selection")
    channels = list_channels(client)
    
    if channels:
        channel_options = {f"{channel['name']} ({channel['id']})": channel['id'] 
                         for channel in channels}
        selected_channels = st.sidebar.multiselect(
            "Select channels to analyze:",
            options=list(channel_options.keys())
        )
        
        selected_channel_ids = [channel_options[channel] for channel in selected_channels]
    else:
        st.sidebar.error("No channels available")
        return

    # Main content area
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Message Analysis")
        days_to_analyze = st.number_input("Days to analyze:", min_value=1, value=1)
        
        if st.button("Analyze Messages"):
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            try:
                all_messages = []
                
                # Process channels one by one with progress updates
                for i, channel_id in enumerate(selected_channel_ids):
                    status_text.text(f"Fetching messages from channel {i+1}/{len(selected_channel_ids)}...")
                    messages = get_channel_messages(client, channel_id, days_to_analyze)
                    all_messages.extend(messages)
                    progress_bar.progress((i + 0.5) / len(selected_channel_ids))
                    time.sleep(0.1)  # Small delay to prevent resource exhaustion
                    
                if all_messages:
                    status_text.text("Generating summary...")
                    summary = summarize_conversation(all_messages)
                    st.session_state.summary = summary
                    progress_bar.progress(0.7)
                    
                    status_text.text("Identifying actionable messages...")
                    actionable = identify_actionable_messages(all_messages)
                    st.session_state.actionable_messages = actionable
                    progress_bar.progress(0.9)
                    
                    # Store messages at the end to reduce memory pressure
                    st.session_state.messages = all_messages[:100]  # Store only first 100 to save memory
                    
                    # Save state to disk
                    save_state()
                    
                    progress_bar.progress(1.0)
                    status_text.text("Analysis complete!")
                    st.success("Analysis complete!")
                else:
                    progress_bar.progress(1.0)
                    status_text.text("No messages found")
                    st.warning(f"No messages found in the selected timeframe")
                    
            except Exception as e:
                st.error(f"Error during analysis: {e}")
                import traceback
                st.error(traceback.format_exc())

    with col2:
        st.subheader("Search Messages")
        search_query = st.text_input("Enter search query:")
        days_to_search = st.slider("Days to search:", 1, 30, 7)
        
        if st.button("Search"):
            if search_query:
                with st.spinner("Searching..."):
                    try:
                        results = smart_search(client, search_query, selected_channel_ids, days_to_search)
                        st.session_state.search_results = results
                        
                        # Save state to disk
                        save_state()
                        
                        display_search_results(results)
                    except Exception as e:
                        st.error(f"Error during search: {e}")
            else:
                st.warning("Please enter a search query")

    # Results display
    st.header("Results")
    tabs = st.tabs(["Summary", "To-Do List", "Search Results"])

    with tabs[0]:
        if st.session_state.summary:
            st.markdown(f"""
                <div style='background-color: #f0f2f6; 
                          padding: 15px; 
                          border-radius: 5px; 
                          border-left: 5px solid #ff4b4b;'>
                {st.session_state.summary}
                </div>
            """, unsafe_allow_html=True)
        else:
            st.info("Run analysis to see summary")

    with tabs[1]:
        display_todo_list(client)

    with tabs[2]:
        if st.session_state.search_results:
            display_search_results(st.session_state.search_results)
        else:
            st.info("No search results to display")
    
    # Final memory cleanup
    clear_memory()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        st.error(f"Application error: {e}")
        import traceback
        st.error(traceback.format_exc())
